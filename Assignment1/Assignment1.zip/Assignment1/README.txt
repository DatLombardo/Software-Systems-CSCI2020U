Read Me:
Michael Lombardo
100588642
CSCI 2020U: Assignment 1
Spam Buster 9999

For Simplicity Sake, I also pushed a compressed zip of the whole project folder.
I also included a folder of pictures of the Spam Buster 9999's usage.

Usage:
Boot in IntelliJ and press run, the pre-configured main class.

When Running:
Upon starting the program you will be prompted to select the data folder. so
highlight the data folder and click open, after that there should be some
console output notifying you what stage of the computation you are in,
processing training and processing testing, which should take approx. 3-5 seconds.
After that you should be displayed the output table, which will have both testing
files compressed into one map, and a Label on the bottom with the accuracy and
precision.

The program will not close until you terminate the program for the sake of
review of the spam detector.


Precision: 0.96921975566213314
Accuracy: 0.9131212012870933